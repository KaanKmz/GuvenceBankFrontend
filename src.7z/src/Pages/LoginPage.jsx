﻿import React, { useState } from "react";
import axios from "../Api/Api";
import { useNavigate } from "react-router-dom";

const LoginPage = () => {
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState("");

    const validateForm = () => {
        const newErrors = {};
        if (!email) newErrors.email = "Email adresi boş bırakılamaz.";
        else if (!email.includes("@")) newErrors.email = "Geçerli bir e-posta adresi girin.";
        if (!password) newErrors.password = "Şifre boş bırakılamaz.";
        return newErrors;
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setErrors({});
        setServerError("");

        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }

        try {
            const res = await axios.post("/Auth/login", {
                email,
                password,
            });

            const token = res.data.token;
            localStorage.setItem("token", token);
            navigate("/profile");

        } catch (error) {
            const errorMsg =
                error.response?.data?.message || "Giriş başarısız. Bilgileri kontrol edin.";
            setServerError(errorMsg);
        }
    };

    return (
        <div style={{ padding: "30px" }}>
            <h1>Giriş Yap</h1>

            {serverError && (
                <p style={{ color: "red", fontWeight: "bold", marginBottom: "10px" }}>
                    {serverError}
                </p>
            )}

            <form onSubmit={handleLogin}>
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                {errors.email && (
                    <p style={{ color: "red", margin: 0 }}>{errors.email}</p>
                )}
                <br />

                <input
                    type="password"
                    placeholder="Şifre"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                {errors.password && (
                    <p style={{ color: "red", margin: 0 }}>{errors.password}</p>
                )}
                <br />

                <button type="submit">Giriş Yap</button>
            </form>
        </div>
    );
};

export default LoginPage;
