﻿import React, { useEffect, useState } from "react";
import axios from "../Api/Api";
import { useNavigate } from "react-router-dom";

const ProfilePage = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [error, setError] = useState("");
    const [formErrors, setFormErrors] = useState({});
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const res = await axios.get("/Auth/me");
                setUser(res.data);
                setUsername(res.data.username);
                setEmail(res.data.email);
            } catch (err) {
                setError("Profil bilgileri alınamadı.");
                if (err.response?.status === 401) {
                    navigate("/login");
                }
            }
        };
        fetchProfile();
    }, [navigate]);

    const validateProfileForm = () => {
        const errors = {};
        if (!username) errors.username = "Kullanıcı adı boş bırakılamaz.";
        if (!email) errors.email = "Email boş bırakılamaz.";
        else if (!email.includes("@")) errors.email = "Geçerli bir email girin.";
        return errors;
    };

    const validatePasswordForm = () => {
        const errors = {};
        if (!currentPassword) errors.currentPassword = "Mevcut şifre boş bırakılamaz.";
        if (!newPassword) errors.newPassword = "Yeni şifre boş bırakılamaz.";
        return errors;
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        setFormErrors({});

        const errors = validateProfileForm();
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        try {
            await axios.put("/Auth/profile", { username, email });
            alert("Bilgiler güncellendi!");
        } catch (err) {
            alert("Güncelleme sırasında hata oluştu.");
        }
    };

    const handlePasswordChange = async (e) => {
        e.preventDefault();
        setFormErrors({});

        const errors = validatePasswordForm();
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        try {
            await axios.put("/Auth/change-password", {
                currentPassword,
                newPassword,
            });
            alert("Şifre başarıyla güncellendi!");
            setCurrentPassword("");
            setNewPassword("");
        } catch (err) {
            const msg = err.response?.data?.message || "Şifre güncellenemedi.";
            alert("Hata: " + msg);
        }
    };

    const handleDelete = async () => {
        if (!window.confirm("Hesabını silmek istediğine emin misin?")) return;
        try {
            await axios.delete("/Auth/profile");
            localStorage.removeItem("token");
            navigate("/register");
        } catch (err) {
            alert("Hesap silinirken hata oluştu.");
        }
    };

    if (!user) return <p>Yükleniyor...</p>;

    return (
        <div style={{ padding: "30px" }}>
            <h2>Profil Sayfası</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}

            <form onSubmit={handleUpdate}>
                <input
                    type="text"
                    placeholder="Kullanıcı Adı"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                {formErrors.username && <p style={{ color: "red" }}>{formErrors.username}</p>}
                <br />

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                {formErrors.email && <p style={{ color: "red" }}>{formErrors.email}</p>}
                <br />

                <button type="submit">Güncelle</button>
            </form>

            <hr />
            <h3>Şifre Değiştir</h3>
            <form onSubmit={handlePasswordChange}>
                <input
                    type="password"
                    placeholder="Mevcut Şifre"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                />
                {formErrors.currentPassword && <p style={{ color: "red" }}>{formErrors.currentPassword}</p>}
                <br />

                <input
                    type="password"
                    placeholder="Yeni Şifre"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                />
                {formErrors.newPassword && <p style={{ color: "red" }}>{formErrors.newPassword}</p>}
                <br />

                <button type="submit">Şifreyi Güncelle</button>
            </form>

            <br />
            <button onClick={handleDelete} style={{ color: "red" }}>
                Hesabımı Sil
            </button>
        </div>
    );
};

export default ProfilePage;
