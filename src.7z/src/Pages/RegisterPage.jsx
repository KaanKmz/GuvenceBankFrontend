﻿import React, { useState } from "react";
import axios from "../Api/Api";
import { useNavigate } from "react-router-dom";

const RegisterPage = () => {
    const navigate = useNavigate();

    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState("");

    const validateForm = () => {
        const newErrors = {};
        if (!username) newErrors.username = "Kullanıcı adı boş bırakılamaz.";
        if (!email) newErrors.email = "Email adresi boş bırakılamaz.";
        else if (!email.includes("@")) newErrors.email = "Geçerli bir e-posta adresi girin.";
        if (!password) newErrors.password = "Şifre boş bırakılamaz.";
        return newErrors;
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        setErrors({});
        setServerError("");

        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }

        try {
            await axios.post("/Auth/register", {
                username,
                email,
                password,
            });
            navigate("/login");
        } catch (error) {
            const msg =
                error.response?.data?.message || "Bu isimde bir kullanıcı zaten kayıtlı.";
            setServerError(msg);
        }
    };

    return (
        <div style={{ padding: "30px" }}>
            <h2>Kayıt Ol</h2>

            {serverError && (
                <p style={{ color: "red", fontWeight: "bold", marginBottom: "10px" }}>
                    {serverError}
                </p>
            )}

            <form onSubmit={handleRegister}>
                <input
                    type="text"
                    placeholder="Kullanıcı Adı"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                {errors.username && (
                    <p style={{ color: "red", margin: 0 }}>{errors.username}</p>
                )}
                <br />

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                {errors.email && (
                    <p style={{ color: "red", margin: 0 }}>{errors.email}</p>
                )}
                <br />

                <input
                    type="password"
                    placeholder="Şifre"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                {errors.password && (
                    <p style={{ color: "red", margin: 0 }}>{errors.password}</p>
                )}
                <br />

                <button type="submit">Kayıt Ol</button>
            </form>
        </div>
    );
};

export default RegisterPage;
